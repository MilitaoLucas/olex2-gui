import boost.python
ext = boost.python.import_ext("cctbx_math_ext")
from cctbx_math_ext import *
