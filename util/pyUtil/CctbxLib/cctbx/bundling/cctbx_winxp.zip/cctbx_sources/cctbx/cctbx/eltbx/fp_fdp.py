import boost.python
ext = boost.python.import_ext("cctbx_eltbx_fp_fdp_ext")
from cctbx_eltbx_fp_fdp_ext import *
