import boost.python
ext = boost.python.import_ext("cctbx_eltbx_neutron_ext")
from cctbx_eltbx_neutron_ext import *
