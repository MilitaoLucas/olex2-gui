import boost.python
ext = boost.python.import_ext("cctbx_eltbx_tiny_pse_ext")
from cctbx_eltbx_tiny_pse_ext import *
