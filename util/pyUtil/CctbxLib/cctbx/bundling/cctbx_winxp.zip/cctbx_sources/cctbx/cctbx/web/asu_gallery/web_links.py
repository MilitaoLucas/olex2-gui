default_http_server_name="cci.lbl.gov"
iucrcompcomm_jul2003 = \
  "http://cci.lbl.gov/publications/download/iucrcompcomm_jul2003.pdf"
