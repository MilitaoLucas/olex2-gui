#! /bin/sh
eval "$@"
