import time

def run():
  print time.time()

if (__name__ == "__main__"):
  run()
