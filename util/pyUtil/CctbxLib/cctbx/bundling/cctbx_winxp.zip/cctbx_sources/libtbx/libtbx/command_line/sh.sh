exec sh "$@"
