import pydoc

def run():
  pydoc.cli()

if (__name__ == "__main__"):
  run()
