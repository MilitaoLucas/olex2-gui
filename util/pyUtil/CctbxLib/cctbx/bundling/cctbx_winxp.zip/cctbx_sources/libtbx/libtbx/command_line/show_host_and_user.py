from libtbx.utils import host_and_user

def run():
  host_and_user().show()

if (__name__ == "__main__"):
  run()
