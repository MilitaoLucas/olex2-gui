import libtbx.load_env

def run():
  libtbx.env.build_options.report()

if (__name__ == "__main__"):
  run()
