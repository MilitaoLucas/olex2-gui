import IPython
if (__name__ == "__main__"):
  IPython.Shell.start().mainloop()
