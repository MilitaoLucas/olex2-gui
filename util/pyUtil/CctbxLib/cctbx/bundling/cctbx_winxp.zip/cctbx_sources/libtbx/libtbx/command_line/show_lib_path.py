import libtbx.load_env

def run():
  print libtbx.env.lib_path

if (__name__ == "__main__"):
  run()
