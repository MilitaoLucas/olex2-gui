exec tcsh "$@"
