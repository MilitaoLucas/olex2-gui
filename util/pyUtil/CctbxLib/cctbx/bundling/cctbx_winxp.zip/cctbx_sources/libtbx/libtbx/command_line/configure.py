import libtbx.config
import sys

if (__name__ == "__main__"):
  libtbx.config.warm_start(sys.argv)
