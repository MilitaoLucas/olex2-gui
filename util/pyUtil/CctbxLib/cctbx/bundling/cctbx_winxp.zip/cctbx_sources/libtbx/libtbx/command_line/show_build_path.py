import libtbx.load_env

def run():
  print libtbx.env.build_path

if (__name__ == "__main__"):
  run()
