from iotbx.cns import reflection_reader
import sys
if (__name__ == "__main__"):
  reflection_reader.run(sys.argv[1:])
