import boost.std_pair

def run():
  boost.std_pair.exercise(2) == (4,1.)
  boost.std_pair.exercise(4) == (16,2.)
  print "OK"

if __name__ == '__main__':
  run()
