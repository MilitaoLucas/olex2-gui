import boost.python
ext = boost.python.import_ext("std_pair_ext")
from std_pair_ext import *
