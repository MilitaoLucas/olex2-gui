from __future__ import division
import libtbx.load_env
execfile(libtbx.env.under_dist("boost_adaptbx", "tst_rational.py"))
