class behaviour_of_variable(object):

  (free, fixed,
   p_times_fv_minus_1, p_times_fv,
   p_times_previous_u_eq) = xrange(5)
