from iotbx.cns import sdb_reader
import sys
if (__name__ == "__main__"):
  sdb_reader.run(sys.argv[1:])
