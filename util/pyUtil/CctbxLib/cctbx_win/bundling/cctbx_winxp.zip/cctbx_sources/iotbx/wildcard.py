import boost.python
ext = boost.python.import_ext("iotbx_wildcard_ext")
from iotbx_wildcard_ext import *
