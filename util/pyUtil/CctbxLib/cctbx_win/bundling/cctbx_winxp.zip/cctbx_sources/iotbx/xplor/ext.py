import boost.python
ext = boost.python.import_ext("iotbx_xplor_ext")
from iotbx_xplor_ext import *
