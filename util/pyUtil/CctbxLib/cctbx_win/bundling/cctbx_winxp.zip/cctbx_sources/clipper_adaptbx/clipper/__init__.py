import boost.python
ext = boost.python.import_ext("clipper_ext")
from clipper_ext import *
