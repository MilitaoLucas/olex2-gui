exec csh "$@"
