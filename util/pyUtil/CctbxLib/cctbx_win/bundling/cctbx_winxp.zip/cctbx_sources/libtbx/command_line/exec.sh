#! /bin/sh
eval "$@"
