exec bash "$@"
