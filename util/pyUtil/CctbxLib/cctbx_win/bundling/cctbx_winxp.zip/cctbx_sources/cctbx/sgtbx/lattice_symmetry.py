from cctbx import sgtbx
group = sgtbx.lattice_symmetry_group
find_max_delta = sgtbx.lattice_symmetry_find_max_delta
